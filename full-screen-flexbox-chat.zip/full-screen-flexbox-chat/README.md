# Full Screen  Flexbox chat

A Pen created on CodePen.io. Original URL: [https://codepen.io/arthak/pen/oWEwqB](https://codepen.io/arthak/pen/oWEwqB).

Hello there, good folks!  Today I created  direct messaging screen with bubbles, nice smooth animation, and some cool dynamics, with pure css3 and html5 with almost no jQuery. How do you like it? :)